# Visualizzazione scientifica
### *Approfondimento sul cinema*
<hr />

## Autori
984605 Pomayay Gabonal Angello Fernando  
01553A Mbaye Serigne Darou
<hr />

## Descrizione progetto
Il nostro progetto di visualizzazione scientifica, sviluppato utilizzando Jupyter in Python, 
si propone di offrire un'esperienza di visualizzazione avanzata e dinamica dei dati. Abbiamo 
adottato la potente libreria Plotly per la creazione dei grafici, poiché offre una vasta gamma 
di funzionalità interattive e una maggiore flessibilità rispetto a molte altre librerie di 
visualizzazione.

Una delle caratteristiche principali del nostro progetto è l'utilizzo di un approccio dinamico 
per la visualizzazione dei dati. Piuttosto che generare molteplici immagini statiche dello stesso
grafico utilizzando matplotlib, abbiamo scelto di implementare un codice dinamico che permette di 
mostrare più dati su un solo grafico. Questo non solo rende più efficiente il processo di 
visualizzazione, ma consente anche agli utenti di interagire direttamente con il grafico, 
esplorando i dati in modo più intuitivo e approfondito.

A

Inoltre, la nostra soluzione basata su Plotly offre un supporto nativo per la visualizzazione in 3D,
consentendo agli utenti di esplorare dati multidimensionali in modo ancora più dettagliato e coinvolgente.

Complessivamente, il nostro progetto di visualizzazione scientifica si distingue per la sua
combinazione di potenza analitica, flessibilità e interattività, offrendo agli utenti uno strumento 
completo per esplorare e comprendere i dati scientifici in modo più efficace e coinvolgente.