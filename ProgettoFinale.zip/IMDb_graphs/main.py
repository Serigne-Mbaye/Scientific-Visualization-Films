# Non è stato utilizzato il main in quanto abbiamo deciso di creare i grafici tramite Jupyter
